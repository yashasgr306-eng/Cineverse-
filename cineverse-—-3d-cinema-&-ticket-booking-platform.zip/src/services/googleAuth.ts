import { getApp, getApps, initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User as FirebaseUser,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export const GOOGLE_SCOPES = [
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
] as const;

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
for (const scope of GOOGLE_SCOPES) {
  provider.addScope(scope);
}
provider.setCustomParameters({
  prompt: 'select_account',
});

// OAuth access token is strictly cached in memory (never localStorage/sessionStorage).
let cachedAccessToken: string | null = null;
let isSigningIn = false;

export interface GoogleSignInResult {
  firebaseUser: FirebaseUser;
  idToken: string;
  accessToken: string | null;
  email: string;
  name: string;
  avatarUrl?: string;
}

export function initGoogleAuthObserver(
  onSignedIn?: (user: FirebaseUser, accessToken: string | null) => void,
  onSignedOut?: () => void
) {
  return onAuthStateChanged(auth, (firebaseUser) => {
    if (firebaseUser) {
      if (cachedAccessToken) {
        onSignedIn?.(firebaseUser, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
      }
    } else {
      cachedAccessToken = null;
      onSignedOut?.();
    }
  });
}

export async function signInWithGooglePopup(): Promise<GoogleSignInResult> {
  isSigningIn = true;
  try {
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const accessToken = credential?.accessToken ?? null;
    cachedAccessToken = accessToken;

    const idToken = await result.user.getIdToken();
    const email = result.user.email?.trim() || '';
    const name = result.user.displayName?.trim() || email.split('@')[0] || 'CINEVERSE Guest';
    const avatarUrl = result.user.photoURL || undefined;

    if (!email) {
      throw new Error('Google account did not return a verified email address.');
    }

    return {
      firebaseUser: result.user,
      idToken,
      accessToken,
      email,
      name,
      avatarUrl,
    };
  } finally {
    isSigningIn = false;
  }
}

export function getGoogleAccessToken(): string | null {
  return cachedAccessToken;
}

export async function signOutGoogle(): Promise<void> {
  cachedAccessToken = null;
  try {
    await signOut(auth);
  } catch {
    // Ignore if user wasn't signed in with Firebase
  }
}
